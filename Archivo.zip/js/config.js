window._config = {
    cognito: {
        userPoolId: 'us-east-2_4l4nY0FHz', // e.g. us-east-2_4l4nY0FHz
        userPoolClientId: '64977csm4qe9emvsk6dcudr5fi', // e.g. 64977csm4qe9emvsk6dcudr5fi
        region: 'us-east-2' // e.g. us-east-2
    },
    api: {
        invokeUrl: 'https://qjaek0l5yl.execute-api.us-east-2.amazonaws.com/prod' // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod,
    }
};
